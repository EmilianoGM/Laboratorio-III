<html>
<head>
	<title>LOGIN</title>
	  
		<meta charset="UTF-8">
        <script src="manejador6.js"></script>
</head>
<body>
			<h1>LOGIN</h1>      				
                <input type="text" id="clave" name="clave" placeholder="Ingrese clave"  />
                <input type="text" id="correo" name="correo" placeholder="Ingrese correo"  />
				<button onclick="AjaxPOST()">Click Me!</button>
</body>
</html>