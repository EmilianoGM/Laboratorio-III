<?php
class Usuario{
    public $id;
    public $nombre;
    public $apellido;
    public $clave;
    public $perfil;
    public $estado;
    public $correo;

    public function NuevoUsuario()
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        
        $consulta =$objetoAccesoDato->RetornarConsulta("INSERT INTO usuarios(nombre, apellido,clave,perfil,estado,correo) "
        ."VALUES (:nombre,:apellido,:clave,:perfil,:estado,:correo)");
        $consulta->bindValue(':id', $this->id, PDO::PARAM_INT);
        $consulta->bindValue(':nombre', $this->nombre, PDO::PARAM_STR);
        $consulta->bindValue(':apellido', $this->apellido, PDO::PARAM_STR);
        $consulta->bindValue(':clave', $this->clave, PDO::PARAM_STR);
        $consulta->bindValue(':perfil', $this->perfil, PDO::PARAM_INT);
        $consulta->bindValue(':estado', $this->estado, PDO::PARAM_INT);
        $consulta->bindValue(':correo', $this->correo, PDO::PARAM_STR);

        $consulta->execute();
    }
    public static function ExisteEnDB($claveABuscar, $correoABuscar)
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta =$objetoAccesoDato->RetornarConsulta("SELECT * FROM usuarios WHERE clave = :clave AND correo = :correo");
        $consulta->bindParam(':clave', $claveABuscar,PDO::PARAM_STR);
        $consulta->bindParam(':correo', $correoABuscar, PDO::PARAM_STR);
        $consulta->execute();
        $resultado = $consulta->fetch();
        return !(empty($resultado));/*
        if(empty($resultado)){
            return "vacio";
        } else{
            return "consulta con resultado";
        }*/
    }

}
?>