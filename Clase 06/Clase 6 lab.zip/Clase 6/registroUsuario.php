<?php
require_once "./usuario.php";
require_once "./AccesoDatos.php";

$user = isset($_POST["usuario"]) ? $_POST["usuario"] : NULL;
$op = isset($_POST["op"]) ? $_POST["op"] : null;

if($user != NULL){
    $obj = json_decode($user);
    $nuevoUsuario = new Usuario();
    $nuevoUsuario->nombre = $obj->nombre;
    $nuevoUsuario->apellido = $obj->apellido;
    $nuevoUsuario->clave = $obj->clave;
    $nuevoUsuario->perfil = $obj->perfil;
    $nuevoUsuario->correo = $obj->correo;
    $nuevoUsuario->estado = 1;
    var_dump($nuevoUsuario);
}

switch ($op) {

    case "subirFoto":

        $objRetorno = new stdClass();
        $objRetorno->Ok = false;

        $destino = "./fotos/" . date("Ymd_His") . ".jpg";
        
        if(move_uploaded_file($_FILES["foto"]["tmp_name"], $destino) ){
            $objRetorno->Ok = true;
            $objRetorno->Path = $destino;
        }

        echo "subida";
        //echo json_encode($objRetorno);

        break;

    default:
        echo "sin foto";
        break;
}
?>