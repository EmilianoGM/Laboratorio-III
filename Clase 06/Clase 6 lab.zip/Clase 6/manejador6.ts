function AjaxPOST():void {
    let xhttp : XMLHttpRequest = new XMLHttpRequest();
    //METODO; URL; ASINCRONICO?
    xhttp.open("POST", "./testUsuario.php", true);
    let correo = (<HTMLTextAreaElement>document.getElementById("correo")).value;
    let clave = (<HTMLTextAreaElement>document.getElementById("clave")).value;
    //SETEO EL ENCABEZADO DE LA PETICION	
    xhttp.setRequestHeader("content-type","application/x-www-form-urlencoded");
    
    //ENVIO DE LA PETICION CON LOS PARAMETROS
    var usuario = 'usuario={"correo":"' + correo + '", "clave":"' + clave + '"}';
    xhttp.send(usuario);

    //FUNCION CALLBACK
    xhttp.onreadystatechange = () => {
        if (xhttp.readyState == 4 && xhttp.status == 200) {
            //var respuesta = JSON.stringify(xhttp.responseText);
            console.log(xhttp.responseText);
        }
    };
}

function CrearUsuario(){
    let xhttp : XMLHttpRequest = new XMLHttpRequest();
    //METODO; URL; ASINCRONICO?
    xhttp.open("POST", "./registroUsuario.php", true);
    //INFO
    let nombre = (<HTMLTextAreaElement>document.getElementById("nombre")).value;
    let apellido = (<HTMLTextAreaElement>document.getElementById("apellido")).value;
    let perfil = (<HTMLTextAreaElement>document.getElementById("perfil")).value;
    let correo = (<HTMLTextAreaElement>document.getElementById("correo")).value;
    let clave = (<HTMLTextAreaElement>document.getElementById("clave")).value;

    //--------------FOTO----
    let foto : any = (<HTMLInputElement> document.getElementById("foto"));
    //INSTANCIO OBJETO FORMDATA
    let form : FormData = new FormData();
    //AGREGO PARAMETROS AL FORMDATA:
    //PARAMETRO RECUPERADO POR $_FILES
    form.append('foto', foto.files[0]);
    form.append('op', "subirFoto");
    //---------------FIN info FOTO----------------------

    //SETEO EL ENCABEZADO DE LA PETICION	
    xhttp.setRequestHeader("content-type","application/x-www-form-urlencoded");
    var usuario = 'usuario={"nombre":"' + nombre + '", "apellido":"' + apellido + '", "perfil":' + perfil
    + ', "correo":"' + correo + '", "clave":"' + clave + '"}';
    xhttp.send(usuario);
    //ENCABEZADO PARA FOTO
    xhttp.setRequestHeader("enctype", "multipart/form-data");
    xhttp.send(form);

    //FUNCION CALLBACK
    xhttp.onreadystatechange = () => {
        if (xhttp.readyState == 4 && xhttp.status == 200) {
            //var respuesta = JSON.stringify(xhttp.responseText);
            console.log(xhttp.responseText);
        }
    };
}