<?php
require_once "./usuario.php";
require_once "./AccesoDatos.php";

$user = isset($_POST["usuario"]) ? $_POST["usuario"] : NULL;
if($user != NULL){
    $obj = json_decode($user);
    $clave = $obj->clave;
    $correo = $obj->correo;
    var_dump($correo);
    var_dump($clave);
    $respuesta = Usuario::ExisteEnDB($clave, $correo);
    //$respuesta = Usuario::ExisteEnDB("65473", "abc@mail.com");
    var_dump($respuesta);
    
    //echo json_encode($respuesta);
} else{
    echo "no hay respuesta";
}
?>