<html>
<head>
	<title>REGISTRO</title>
	  
		<meta charset="UTF-8">
        <script src="manejador6.js"></script>
</head>
<body>
    <h1>REGISTRO</h1>
    <input type="text" id="nombre" name="nombre" placeholder="Ingrese nombre"  />
    <input type="text" id="apellido" name="apellido" placeholder="Ingrese apellido"  />
    <input type="text" id="perfil" name="perfil" placeholder="Ingrese perfil"  />
    <input type="text" id="clave" name="clave" placeholder="Ingrese clave"  />
    <input type="text" id="correo" name="correo" placeholder="Ingrese correo"  />
    <input type="file" id="foto" style="color:blue" />
    <button onclick="CrearUsuario()">Click Me!</button>
</body>
</html>