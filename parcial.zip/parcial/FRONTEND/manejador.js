var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Entidades;
(function (Entidades) {
    var Producto = /** @class */ (function () {
        function Producto(codigo, marca, precio) {
            this.codigo = codigo;
            this.marca = marca;
            this.precio = precio;
        }
        Producto.prototype.ToString = function () {
            return '"codigo":' + this.codigo + ',"marca":"' + this.marca + '","precio":' + this.precio;
        };
        return Producto;
    }());
    Entidades.Producto = Producto;
})(Entidades || (Entidades = {}));
var Entidades;
(function (Entidades) {
    var Televisor = /** @class */ (function (_super) {
        __extends(Televisor, _super);
        function Televisor(codigo, marca, precio, tipo, paisOrigen, pathFoto) {
            if (pathFoto === void 0) { pathFoto = ""; }
            var _this = _super.call(this, codigo, marca, precio) || this;
            _this.tipo = tipo;
            _this.paisOrigen = paisOrigen;
            _this.pathFoto = pathFoto;
            return _this;
        }
        Televisor.prototype.ToJson = function () {
            return '{' + _super.prototype.ToString.call(this) + ',"tipo":"' + this.tipo + '","paisOrigen":"' + this.paisOrigen +
                '","pathFoto":"' + this.pathFoto + '"}';
        };
        return Televisor;
    }(Entidades.Producto));
    Entidades.Televisor = Televisor;
})(Entidades || (Entidades = {}));
/// <reference path="./Televisor.ts" />
var PrimerParcial;
(function (PrimerParcial) {
    var Manejadora = /** @class */ (function () {
        function Manejadora() {
        }
        Manejadora.prototype.AgregarTelevisor = function () {
            var xhttp = new XMLHttpRequest();
            xhttp.open("POST", "./BACKEND/administrar.php", true);
            xhttp.setRequestHeader("enctype", "multipart/form-data");
            var codigo = +document.getElementById("codigo").value;
            var marca = document.getElementById("marca").value;
            var precio = +document.getElementById("precio").value;
            var tipo = document.getElementById("tipo").value;
            var paisOrigen = document.getElementById("pais").value;
            var foto = document.getElementById("foto");
            var pathFoto = codigo + ".jpg";
            var televisor = new Entidades.Televisor(codigo, marca, precio, tipo, paisOrigen, pathFoto);
            var form = new FormData();
            var cadenaJson = televisor.ToJson();
            form.append('foto', foto.files[0]);
            form.append('caso', "agregar");
            form.append('cadenaJson', cadenaJson);
            xhttp.send(form);
            xhttp.onreadystatechange = function () {
                if (xhttp.readyState == 4 && xhttp.status == 200) {
                    //var respuesta = JSON.parse(xhttp.responseText);
                    console.log(xhttp.responseText);
                }
            };
        };
        Manejadora.prototype.MostrarTelevisores = function () {
            var xhttp = new XMLHttpRequest();
            xhttp.open("POST", "./BACKEND/administrar.php", true);
            xhttp.setRequestHeader("content-type", "application/x-www-form-urlencoded");
            var caso = "traer";
            xhttp.send("caso=" + caso);
            xhttp.onreadystatechange = function () {
                if (xhttp.readyState == 4 && xhttp.status == 200) {
                    var listado = JSON.parse(xhttp.responseText);
                    var div = document.getElementById("divTabla");
                    var tabla = "<table border='1'>" +
                        "<tr><td>Codigo</td><td>Marca</td><td>Precio</td><td>Tipo</td><td>Pais</td>" +
                        "<td>Foto</td>" +
                        "</tr>";
                    for (var index = 0; index < listado.length; index++) {
                        var televisor = listado[index];
                        tabla += "<tr><td>" + televisor["codigo"] + "</td><td>" + televisor["marca"] + "</td><td>" +
                            televisor["precio"] + "</td><td>" + televisor["tipo"] + "</td><td>" + televisor["paisOrigen"] +
                            "</td><td><img src='./BACKEND/fotos/" + televisor["pathFoto"] + "'height='100' width='100'></td></tr>";
                    }
                    tabla += "</table>";
                    div.innerHTML = tabla;
                }
            };
        };
        Manejadora.prototype.GuardarEnLocalStorage = function () {
            var xhttp = new XMLHttpRequest();
            xhttp.open("POST", "./BACKEND/administrar.php", true);
            xhttp.setRequestHeader("content-type", "application/x-www-form-urlencoded");
            var caso = "traer";
            xhttp.send("caso=" + caso);
            xhttp.onreadystatechange = function () {
                if (xhttp.readyState == 4 && xhttp.status == 200) {
                    var listado = JSON.parse(xhttp.responseText);
                    localStorage.setItem("televisores_local_storage", JSON.stringify(listado));
                    if (localStorage.getItem("televisores_local_storage") != null) {
                        console.log("local storage hecho");
                    }
                }
            };
        };
        Manejadora.prototype.VerificarExistencia = function () {
            if (localStorage.getItem("televisores_local_storage") != null) {
                var flag = true;
                var items = localStorage.getItem("televisores_local_storage");
                var listado = JSON.parse("" + items);
                var codigo = +document.getElementById("codigo").value;
                for (var index = 0; index < listado.length; index++) {
                    var televisor = listado[index];
                    if (televisor["codigo"] == codigo) {
                        flag = false;
                        break;
                    }
                }
                if (flag) {
                    var manejadora = new PrimerParcial.Manejadora();
                    manejadora.AgregarTelevisor();
                    manejadora.GuardarEnLocalStorage();
                    console.log("Agregado");
                }
                else {
                    console.log("Ya existe");
                    alert("Ese televisor ya ha sido agregado");
                }
            }
        };
        return Manejadora;
    }());
    PrimerParcial.Manejadora = Manejadora;
})(PrimerParcial || (PrimerParcial = {}));
/// <reference path="./Manejadora.ts" />
function Agregar() {
    var manejadora = new PrimerParcial.Manejadora();
    manejadora.AgregarTelevisor();
}
function Mostrar() {
    var manejadora = new PrimerParcial.Manejadora();
    manejadora.MostrarTelevisores();
}
function GuardarStorage() {
    var manejadora = new PrimerParcial.Manejadora();
    manejadora.GuardarEnLocalStorage();
}
function Verificar() {
    var manejadora = new PrimerParcial.Manejadora();
    manejadora.VerificarExistencia();
}
