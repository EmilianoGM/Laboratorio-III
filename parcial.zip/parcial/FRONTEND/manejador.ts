/// <reference path="./Manejadora.ts" />
function Agregar(){
    var manejadora = new PrimerParcial.Manejadora();
    manejadora.AgregarTelevisor();
}
function Mostrar(){
    var manejadora = new PrimerParcial.Manejadora();
    manejadora.MostrarTelevisores();
}
function GuardarStorage(){
    var manejadora = new PrimerParcial.Manejadora();
    manejadora.GuardarEnLocalStorage();
}
function Verificar(){
    var manejadora = new PrimerParcial.Manejadora();
    manejadora.VerificarExistencia();
}