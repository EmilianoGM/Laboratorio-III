/// <reference path="./Televisor.ts" />
namespace PrimerParcial{
    export class Manejadora{
        public AgregarTelevisor(){
            let xhttp : XMLHttpRequest = new XMLHttpRequest();
            xhttp.open("POST", "./BACKEND/administrar.php", true);
            xhttp.setRequestHeader("enctype", "multipart/form-data");
            
            let codigo = +(<HTMLTextAreaElement>document.getElementById("codigo")).value;
            let marca = (<HTMLTextAreaElement>document.getElementById("marca")).value;
            let precio = +(<HTMLTextAreaElement>document.getElementById("precio")).value;
            let tipo = (<HTMLTextAreaElement>document.getElementById("tipo")).value;
            let paisOrigen = (<HTMLSelectElement>document.getElementById("pais")).value;
            let foto : any = (<HTMLInputElement> document.getElementById("foto"));
            
            var pathFoto : string = codigo + ".jpg"; 
            var televisor : Entidades.Televisor = new Entidades.Televisor(codigo, marca, precio,tipo,paisOrigen,pathFoto);
            let form : FormData = new FormData();
            var cadenaJson = televisor.ToJson();
            form.append('foto', foto.files[0]);
            form.append('caso', "agregar");
            form.append('cadenaJson', cadenaJson);
    
            xhttp.send(form);

            xhttp.onreadystatechange = () => {
                if (xhttp.readyState == 4 && xhttp.status == 200) {
                    //var respuesta = JSON.parse(xhttp.responseText);
                    console.log(xhttp.responseText);
                }
            };
        }
        public MostrarTelevisores(){
            var xhttp = new XMLHttpRequest();
            xhttp.open("POST", "./BACKEND/administrar.php", true);
	
            xhttp.setRequestHeader("content-type", "application/x-www-form-urlencoded");
            let caso = "traer";

            xhttp.send("caso=" + caso);
        
            xhttp.onreadystatechange = function () {
                if (xhttp.readyState == 4 && xhttp.status == 200) {
                    var listado = JSON.parse(xhttp.responseText);
                    var div = (<HTMLDivElement>document.getElementById("divTabla"));
                    let tabla = "<table border='1'>" +
                    "<tr><td>Codigo</td><td>Marca</td><td>Precio</td><td>Tipo</td><td>Pais</td>"+
                    "<td>Foto</td>" +
                    "</tr>";
                    for (let index = 0; index < listado.length; index++) {
                        var televisor = listado[index];
                        tabla += "<tr><td>" + televisor["codigo"] + "</td><td>" + televisor["marca"] + "</td><td>" +
                        televisor["precio"] + "</td><td>"+ televisor["tipo"] + "</td><td>"+ televisor["paisOrigen"] +
                        "</td><td><img src='./BACKEND/fotos/" + televisor["pathFoto"] + "'height='100' width='100'></td></tr>";
                    }
                    tabla +="</table>";
                    div.innerHTML = tabla;
                }
            };
        }

        public GuardarEnLocalStorage(){
            var xhttp = new XMLHttpRequest();
            xhttp.open("POST", "./BACKEND/administrar.php", true);
	
            xhttp.setRequestHeader("content-type", "application/x-www-form-urlencoded");
            let caso = "traer";

            xhttp.send("caso=" + caso);
        
            xhttp.onreadystatechange = function () {
                if (xhttp.readyState == 4 && xhttp.status == 200) {
                    var listado = JSON.parse(xhttp.responseText);
                    localStorage.setItem("televisores_local_storage", JSON.stringify(listado));
                    if(localStorage.getItem("televisores_local_storage") != null){
                        console.log("local storage hecho");
                    }
                }
            };
        }

        public VerificarExistencia(){
                    if(localStorage.getItem("televisores_local_storage") != null){
                        var flag = true;
                        var items = localStorage.getItem("televisores_local_storage");
                        var listado = JSON.parse("" + items);
                        let codigo = +(<HTMLTextAreaElement>document.getElementById("codigo")).value;
                        for (let index = 0; index < listado.length; index++) {
                            var televisor = listado[index];
                            if(televisor["codigo"] == codigo){
                                flag = false;
                                break;
                            }
                        }
                        if(flag){
                            var manejadora = new PrimerParcial.Manejadora();
                            manejadora.AgregarTelevisor();
                            manejadora.GuardarEnLocalStorage();
                            console.log("Agregado");
                        }else{
                            console.log("Ya existe");
                            alert("Ese televisor ya ha sido agregado");
                        }
                    }
        }
        public EliminarTelevisor(codigo : number){
            var xhttp = new XMLHttpRequest();
            xhttp.open("POST", "./BACKEND/administrar.php", true);
	
            xhttp.setRequestHeader("content-type", "application/x-www-form-urlencoded");
            let caso = "eliminar";
            let cadenaJson = "";
            var manejadora = new PrimerParcial.Manejadora();
            manejadora.GuardarEnLocalStorage();
            if(localStorage.getItem("televisores_local_storage") != null){
                var items = localStorage.getItem("televisores_local_storage");
                var listado = JSON.parse("" + items);
                for (let index = 0; index < listado.length; index++) {
                    var televisor = listado[index];
                    if(televisor["codigo"] == codigo){
                        cadenaJson = JSON.stringify(televisor);
                        break;
                    }
                }
            }
            
            xhttp.send("caso=" + caso + "&cadenaJson=");
        
            xhttp.onreadystatechange = function () {
                if (xhttp.readyState == 4 && xhttp.status == 200) {
                    var listado = JSON.parse(xhttp.responseText);
                }
            };
        }
            
    }
}

