///<reference path="node_modules/@types/jquery/index.d.ts"/>

$(document).ready(function () {

    Manejadora.CargarListadoUsuarios();
    //ManejadoraPrincipal.CargarListadoAutos();
});