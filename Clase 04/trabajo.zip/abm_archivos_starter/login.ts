function Loguear() : void{
    var nombre = (<HTMLInputElement>document.getElementById("nombre")).value;
    var id = (<HTMLInputElement>document.getElementById("id")).value;
    
}