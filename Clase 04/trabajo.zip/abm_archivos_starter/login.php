<html>
<head>
	<title>LOGIN</title>
	  
		<meta charset="UTF-8">

		<link href="./img/utnLogo.png" rel="icon" type="image/png" />

        <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="estilo.css">
</head>
<body>
	<div class="container">
	
		<div class="page-header">
			<h1>LOGIN</h1>      
		</div>
		<div class="CajaInicio animated bounceInRight">
			<h1>INGRESAR</h1>>
			<input type="text" name="usuario" placeholder="Ingrese nombre de usuario"  />
            <input type="text" name="clave" placeholder="Ingrese clave"  />
            <button>Aceptar</button>
		</div>
	</div>
</body>
</html>