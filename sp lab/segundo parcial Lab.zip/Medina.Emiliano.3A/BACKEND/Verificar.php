<?php
require_once("./Usuario.php");
$objRetorno = new stdClass();
$objRetorno->Exito = false;
$objRetorno->Mensaje = "No encontrado";

$datos = $_POST['usuario'];
$datosJSON = json_decode($datos);
$usuario = new Usuario(null, $datosJSON->correo, $datosJSON->clave);
$usuarioDB = $usuario->ExisteDB();
if($usuarioDB != false){
    $objRetorno->Exito = true;
    $objRetorno->Mensaje = "Encontrado";
    $objRetorno->Usuario = $usuarioDB;
}


echo json_encode($objRetorno);
?>