<?php
require_once("./Usuario.php");
if(isset($_FILES["foto"])) {
    $objRetorno = new stdClass();
    $objRetorno->Exito = false;
    $objRetorno->Mensaje = "No encontrado";

    $nombre = $_FILES["foto"]['name'];
    $destino = "../fotos/" . $nombre;
    
    if(move_uploaded_file($_FILES["foto"]["tmp_name"], $destino))
    { $objRetorno->Exito = true; }
    else { $objRetorno->Mensaje = "No se pudo subir la foto"; }

    $datos = $_POST['usuario'];
    $datosJSON = json_decode($datos);
    $usuario = new Usuario(null, $datosJSON->correo, $datosJSON->clave, $datosJSON->nombre, $datosJSON->apellido, $datosJSON->perfil, $nombre);

    if($usuario->AgregarDB()){
        $objRetorno->Exito = true;
        $objRetorno->Mensaje = "Agregado";
        
    }

    echo json_encode($objRetorno);
}

?>